<?php
echo "Hello From Sites Folder!";
phpinfo();
